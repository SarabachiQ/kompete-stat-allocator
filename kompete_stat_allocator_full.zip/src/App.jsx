import React, { useState } from 'react';
import { Radar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

const defaultParams = [
  { name: 'Reload', value: 50 },
  { name: 'Acceleration', value: 50 },
  { name: 'Recoil', value: 50 },
  { name: 'Damage Reduction', value: 50 },
  { name: 'Speed', value: 50 },
];

export default function App() {
  const [parameters, setParameters] = useState(defaultParams);
  const [totalPoints, setTotalPoints] = useState(139);

  const updateParam = (index, newValue) => {
    const newParams = [...parameters];
    newParams[index].value = newValue;
    setParameters(newParams);
  };

  const sortedParams = [...parameters].sort((a, b) => b.value - a.value);

  const data = {
    labels: sortedParams.map(p => p.name),
    datasets: [
      {
        label: 'Stats',
        data: sortedParams.map(p => p.value),
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: '#f43f5e',
        borderWidth: 2,
      },
    ],
  };

  const options = {
    scales: {
      r: {
        min: 50,
        max: 99,
        ticks: {
          stepSize: 5,
          color: '#fff',
        },
        pointLabels: {
          color: '#fff',
          font: {
            size: 14,
            family: 'Orbitron',
          },
        },
        grid: {
          color: '#444'
        },
      },
    },
    plugins: {
      legend: {
        labels: {
          color: '#fff',
        },
      },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white font-[Orbitron] p-4">
      <h1 className="text-3xl font-bold text-center mb-4">KOMPETE Style Stat Allocator</h1>
      <Radar data={data} options={options} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
        {parameters.map((param, idx) => (
          <div key={idx} className="flex flex-col">
            <label className="mb-1">{param.name}: {param.value}</label>
            <input
              type="range"
              min={50}
              max={99}
              value={param.value}
              onChange={(e) => updateParam(idx, parseInt(e.target.value))}
              className="w-full"
            />
          </div>
        ))}
      </div>
      <div className="text-center mt-6 text-sm text-gray-400">
        Total Points Used: {parameters.reduce((sum, p) => sum + (p.value - 50), 0)} / {totalPoints}
      </div>
    </div>
  );
}