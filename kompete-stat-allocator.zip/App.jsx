import React, { useState } from "react";
import { Radar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

const MAX = 99;
const MIN = 50;
const TOTAL_POINTS = 139;

const PARAMS = [
  "Reload",
  "Acceleration",
  "Recoil",
  "Damage Reduction",
  "Speed",
];

function generateValues(method) {
  const range = MAX - MIN;
  if (method === "even") {
    const each = Math.floor(TOTAL_POINTS / 5);
    return PARAMS.map(() => MIN + each);
  } else if (method === "curve") {
    const weights = [1, 2, 3, 2, 1];
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    return weights.map((w) => MIN + Math.floor((w / totalWeight) * TOTAL_POINTS));
  } else if (method === "spread") {
    return [99, 90, 80, 60, 50];
  } else {
    return [90, 90, 69, 70, 70];
  }
}

export default function StatAllocator() {
  const [method, setMethod] = useState("custom");
  const [values, setValues] = useState(generateValues("custom"));

  const handleSlider = (index, val) => {
    const newVals = [...values];
    newVals[index] = parseInt(val);
    setValues(newVals);
  };

  const handleMethodChange = (e) => {
    const selected = e.target.value;
    setMethod(selected);
    setValues(generateValues(selected));
  };

  const usedPoints = values.reduce((acc, val) => acc + (val - MIN), 0);
  const remaining = TOTAL_POINTS - usedPoints;

  const radarData = {
    labels: PARAMS,
    datasets: [
      {
        label: "Current Stats",
        data: values,
        backgroundColor: "rgba(255, 99, 132, 0.2)",
        borderColor: "#00ffc6",
        pointBackgroundColor: "#00ffc6",
        borderWidth: 2,
      },
    ],
  };

  const radarOptions = {
    scales: {
      r: {
        suggestedMin: MIN,
        suggestedMax: MAX,
        angleLines: { color: "#333" },
        grid: { color: "#444" },
        pointLabels: { color: "#fff", font: { size: 14 } },
        ticks: { backdropColor: "transparent", color: "#fff" },
      },
    },
    plugins: {
      legend: { labels: { color: "#fff" } },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black to-gray-900 text-white p-6">
      <h1 className="text-3xl font-bold text-center mb-4 text-[#00ffc6]">
        KOMPETE Style Stat Allocator
      </h1>
      <div className="max-w-3xl mx-auto bg-[#1a1a1a] p-6 rounded-2xl shadow-lg space-y-6">
        <div className="flex justify-center gap-4 mb-4">
          <label>Method:</label>
          <select
            value={method}
            onChange={handleMethodChange}
            className="bg-black border border-[#00ffc6] px-2 py-1 rounded text-[#00ffc6]"
          >
            <option value="custom">Manual</option>
            <option value="even">Even</option>
            <option value="curve">Curve</option>
            <option value="spread">Spread</option>
          </select>
        </div>
        <div className="space-y-4">
          {PARAMS.map((param, idx) => (
            <div key={idx}>
              <label className="block text-sm mb-1">
                {param}: {values[idx]}
              </label>
              <input
                type="range"
                min={MIN}
                max={MAX}
                value={values[idx]}
                onChange={(e) => handleSlider(idx, e.target.value)}
                disabled={method !== "custom"}
                className="w-full accent-[#00ffc6]"              />
            </div>
          ))}
        </div>
        <div className="text-center text-lg">
          <span className={remaining < 0 ? "text-red-400" : "text-[#00ffc6]"}>
            Remaining Points: {remaining}
          </span>
        </div>
        <Radar data={radarData} options={radarOptions} />
      </div>
    </div>
  );
}
